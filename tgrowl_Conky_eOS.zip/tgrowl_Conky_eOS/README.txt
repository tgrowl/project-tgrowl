
Contents:
----------------
> tgrowl_Conky_eOS
    >Conky.desktop                  ---     .desktop entry (place in /home/USER/.conky) - can then be linked to Plank
    >elementary
        * conky_elementary.sh       ---     script called from the .desktop file
        * .conky_MAIN               ---     Displays main title bar 'Elementary OS'
        * .conky_SYSINFO            ---     
        * .conky_STORAGE            ---
        * .conky_CORES              ---
        * .conky_RAM                ---
        * .conky_NETWORK            ---
        * .conky_GPU                ---     Uses grep on nvidia-smi command (I think you'll need proprietary drivers installed for this to work)
        * .elem80.png               ---     called by .conky_MAIN
        * launcher_icon.png         ---     called by Conky.desktop


NOTE:
    * All of this was configured specifically for my system.
    * You will need to edit most of the path configurations

Scaling:
    * You may want to try scaling everything down by a factor of 4 to get it to fit on a regular 1920x1080 screen.
        I have yet to try this myself - as I would like to get it to work on my laptop screen too.

