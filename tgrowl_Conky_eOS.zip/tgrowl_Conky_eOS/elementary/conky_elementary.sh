#!/bin/sh
sleep 2
conky -q -c /home/tgrowl/.conky/elementary/.conky_MAIN &
conky -q -c /home/tgrowl/.conky/elementary/.conky_CORES &
conky -q -c /home/tgrowl/.conky/elementary/.conky_RAM &
conky -q -c /home/tgrowl/.conky/elementary/.conky_STORAGE &
conky -q -c /home/tgrowl/.conky/elementary/.conky_GPU &
conky -q -c /home/tgrowl/.conky/elementary/.conky_CLOCK &
conky -q -c /home/tgrowl/.conky/elementary/.conky_NETWORK &
conky -q -c /home/tgrowl/.conky/elementary/.conky_SYSINFO exit
